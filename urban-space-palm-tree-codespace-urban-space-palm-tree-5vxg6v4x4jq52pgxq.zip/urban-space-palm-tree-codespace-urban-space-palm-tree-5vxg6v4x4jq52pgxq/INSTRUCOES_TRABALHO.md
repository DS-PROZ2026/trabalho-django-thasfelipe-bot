# Sistema de Gestão de Ativos - Django

Este projeto usa a estrutura original do Codespace e adiciona o sistema de equipamentos.
Todas as rotas do sistema foram centralizadas em `hello_world/urls.py`.

## Executar no Codespace

```bash
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```

Depois abra a porta 8000.

## Fluxo

1. `/cadastro/` - criar perfil de usuário.
2. `/login/` - entrar no sistema.
3. `/` - dashboard.
4. `/equipamentos/` - listagem dos equipamentos.
5. `/equipamentos/cadastrar/` - cadastrar equipamento.
6. `/equipamento/<id>/` - detalhes de um equipamento.
7. `/perfil/` - perfil do usuário.

## Banco de dados

O projeto usa SQLite (`db.sqlite3`). A tabela de equipamentos é criada pelas migrations do app `meu_app`.

## CSRF / Codespaces

O `settings.py` já aceita `localhost`, o navegador interno do Codespaces e `*.app.github.dev`, evitando o erro 403 de origem não confiável.
